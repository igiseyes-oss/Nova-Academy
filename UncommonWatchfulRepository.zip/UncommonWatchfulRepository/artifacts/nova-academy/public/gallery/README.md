# Nova Academy Gallery

Place certificate samples, course flyers, workshop posters, and activity photos in this folder.

Then open `src/App.tsx` and set an item's `image` value in `galleryItems`, for example:

```ts
image: '/gallery/certificate-sample.jpg'
```

Supported formats include JPG, PNG, and WebP.