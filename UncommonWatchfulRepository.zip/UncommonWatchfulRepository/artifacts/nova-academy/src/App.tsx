import { useEffect, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowRight,
  BookOpen,
  Check,
  ChevronRight,
  GraduationCap,
  Mail,
  Menu,
  MessageCircle,
  Phone,
  Send,
  X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';
import academyArtwork from '@assets/file_00000000539c81fdb2ccb30e4cddeb46_1787642601281.png';
import novaLogo from './assets/nova-logo.png';

const queryClient = new QueryClient();

const WHATSAPP_CHANNEL = 'https://whatsapp.com/channel/0029VbBvshnHwXbE3soJHP1y';
const WHATSAPP_MESSAGE = 'https://wa.me/923086774166';
const LIBRARY_LINK = 'https://drive.google.com/drive/folders/1gHbK2tPR99AeGii0e5KauPv0j2JSNL5o';
const courseWhatsAppLink = (courseTitle: string) =>
  `${WHATSAPP_MESSAGE}?text=${encodeURIComponent(`Assalam o Alaikum, I want registration/details for the ${courseTitle}.`)}`;

const courses = [
  { title: 'AI Course', duration: '15 Days', eligibility: 'Male & Female', delivery: 'Via YouTube', fee: 'Rs. 150', feeNote: '/ student', paid: true },
  { title: 'Pixellab Course', duration: 'Not specified', eligibility: 'Females Only', delivery: 'Via YouTube', fee: 'Rs. 300', feeNote: '/ student', paid: true },
  { title: 'Portfolio Building Course', duration: '10 Days', eligibility: 'Females Only', delivery: 'Via YouTube', fee: 'Rs. 300', feeNote: 'total', paid: true },
  { title: 'Arabic Language Course', duration: '15 Days', eligibility: 'Females Only', delivery: 'Via WhatsApp', fee: 'Free', feeNote: 'of cost', paid: false },
  { title: 'App Development Course', duration: '3 Days', eligibility: 'Male & Female', delivery: 'Via YouTube', fee: 'Free', feeNote: 'of cost', paid: false },
  { title: 'Etsy Course', duration: '1 Month', eligibility: 'Male & Female', delivery: 'Via WhatsApp', fee: 'Rs. 1,500', feeNote: '/ student', paid: true },
  { title: 'Daraz Affiliate Marketing Short Course', duration: '3 Days', eligibility: 'Females Only', delivery: '—', fee: 'Free', feeNote: 'of cost', paid: false },
  { title: 'English Spoken Course', duration: '10 Days', eligibility: 'Females Only', delivery: 'Live Classes', fee: 'Free', feeNote: 'of cost', paid: false },
  { title: 'Digital Square Calligraphy', duration: '1 Month', eligibility: 'Females Only', delivery: 'Via YouTube', fee: 'Rs. 150', feeNote: '/ student', paid: true },
];

const galleryItems = [
  { label: 'NOVA ACADEMY / 01', title: <>AI<br />Course</>, subtitle: '15 days · via YouTube', image: '/gallery/ai-course-poster.jpg', alt: 'AI course poster' },
  { label: 'NOVA ACADEMY / 02', title: <>Learn<br />something new.</>, subtitle: 'Graphic design poster', image: '/gallery/graphic-design-poster.jpg', alt: 'Nova Academy graphic design poster' },
  { label: 'NOVA ACADEMY / 03', title: <>Proof<br />of progress.</>, subtitle: 'Certificate sample', image: '/gallery/certificate-sample.png', alt: 'Nova Academy certificate sample' },
  { label: 'NOVA ACADEMY / 04', title: <>Your next<br />chapter.</>, subtitle: 'Future growth', image: '/gallery/future-growth.jpg', alt: 'Notebook and staircase representing future growth' },
];

const navItems = [
  ['home', 'Home'],
  ['about', 'About Us'],
  ['courses', 'Courses'],
  ['gallery', 'Gallery'],
  ['tuition', 'Online Tuition'],
  ['library', 'Library'],
  ['contact', 'Contact'],
];

function SectionHeader({ eyebrow, title, description, dark = false }: { eyebrow: string; title: string; description: string; dark?: boolean }) {
  return (
    <div className="section-kicker">
      <div className="eyebrow" style={dark ? { color: 'var(--gold-light)' } : undefined}>{eyebrow}</div>
      <h2 className="section-heading">{title}</h2>
      <p className="section-intro">{description}</p>
    </div>
  );
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const sections = navItems.map(([id]) => document.getElementById(id));
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visible[0]?.target.id) setActiveSection(visible[0].target.id);
      },
      { rootMargin: '-22% 0px -62% 0px', threshold: [0.08, 0.25, 0.6] },
    );
    sections.forEach((section) => section && observer.observe(section));
    return () => observer.disconnect();
  }, []);

  const navigate = (id: string) => {
    setMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="nova-page">
      <div className="topbar">
        <div className="nova-container topbar-inner">
          <div className="topbar-details">
            <a className="topbar-detail" href="tel:03086774166" data-testid="link-topbar-phone"><Phone />0308-6774166</a>
            <a className="topbar-detail" href="mailto:nova.learn253@gmail.com" data-testid="link-topbar-email"><Mail />nova.learn253@gmail.com</a>
            <a className="topbar-detail" href={WHATSAPP_CHANNEL} target="_blank" rel="noopener noreferrer" data-testid="link-topbar-whatsapp"><MessageCircle />WhatsApp Channel</a>
          </div>
          <a className="topbar-link" href={WHATSAPP_CHANNEL} target="_blank" rel="noopener noreferrer" data-testid="link-topbar-join"><MessageCircle /> Join WhatsApp Channel</a>
        </div>
      </div>

      <header className="site-header">
        <div className="nova-container nav-row">
            <a className="brand" href="#home" onClick={() => navigate('home')} data-testid="link-brand">
            <span className="brand-mark"><img src={novaLogo} alt="Nova Academy logo" /></span>
            <span>
              <h1 className="brand-name">NOVA <span>ACADEMY</span></h1>
              <small className="brand-tagline">Empowering Youth with Skills</small>
            </span>
          </a>
          <nav className={`main-nav${menuOpen ? ' open' : ''}`} aria-label="Main navigation">
            {navItems.map(([id, label]) => (
              <a
                className={`nav-link${activeSection === id ? ' active' : ''}`}
                href={`#${id}`}
                key={id}
                onClick={() => setMenuOpen(false)}
                data-testid={`link-nav-${id}`}
              >{label}</a>
            ))}
          </nav>
          <div className="button-row">
            <a className="nav-join" href={WHATSAPP_CHANNEL} target="_blank" rel="noopener noreferrer" data-testid="link-nav-join"><MessageCircle size={14} /> Join Channel</a>
            <button className="menu-toggle" type="button" aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'} aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)} data-testid="button-menu-toggle">
              {menuOpen ? <X size={21} /> : <Menu size={21} />}
            </button>
          </div>
        </div>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="nova-container hero-grid">
            <div className="hero-copy reveal">
              <div className="eyebrow">Welcome to</div>
              <h2 className="display hero-title">NOVA <em>ACADEMY</em></h2>
              <p className="hero-lead">Learn valuable skills, explore new opportunities, and grow with confidence.</p>
              <p className="hero-description">Nova Academy is an online learning platform providing skill-based courses and learning opportunities for students from Pakistan and around the world.</p>
              <div className="button-row">
                <a className="button button-primary" href="#courses" data-testid="link-hero-courses"><GraduationCap size={16} /> Explore Courses <ArrowRight size={15} /></a>
                <a className="button button-outline" href={WHATSAPP_CHANNEL} target="_blank" rel="noopener noreferrer" data-testid="link-hero-whatsapp"><MessageCircle size={16} /> Join WhatsApp Channel</a>
              </div>
              <div className="hero-note"><Check size={14} /> Welcoming learners from Pakistan and beyond</div>
            </div>
          </div>
        </section>

        <section className="stats-band" aria-label="Nova Academy highlights">
          <div className="nova-container stats-grid">
            <div className="stat" data-testid="stat-students"><strong className="stat-value">10K+</strong><span className="stat-label">Students Taught</span></div>
            <div className="stat" data-testid="stat-courses"><strong className="stat-value">50+</strong><span className="stat-label">Courses &amp; Workshops</span></div>
            <div className="stat" data-testid="stat-online"><strong className="stat-value">Online</strong><span className="stat-label">Learning Platform</span></div>
            <div className="stat" data-testid="stat-global"><strong className="stat-value">Global</strong><span className="stat-label">National &amp; International Students</span></div>
          </div>
        </section>

        <section className="section about-section" id="about">
          <div className="nova-container about-layout">
            <div className="vision-card" data-testid="card-vision">
              <div className="vision-index">NOVA / OUR VISION</div>
              <h3 className="display">Building skills.<br />Building futures.</h3>
              <p>“We believe that learning a valuable skill can create new opportunities.”</p>
            </div>
            <div className="about-copy">
              <div className="eyebrow">About Us</div>
              <h2 className="section-heading">A focused place to begin.</h2>
              <p>Nova Academy is an online learning platform established in October 2024 with the vision of empowering youth with practical and valuable skills.</p>
              <p>Our mission is to provide skill-based learning opportunities that help students develop useful skills, explore online earning opportunities, and grow personally and professionally.</p>
              <p>Nova Academy welcomes both male and female students and provides online learning opportunities for students from Pakistan as well as international students.</p>
              <div className="about-stats">
                <div className="about-stat" data-testid="about-stat-students"><strong>10,000+</strong><span>Students Taught</span></div>
                <div className="about-stat" data-testid="about-stat-courses"><strong>50+</strong><span>Courses Conducted</span></div>
                <div className="about-stat" data-testid="about-stat-teachers"><strong>Dedicated</strong><span>Teachers’ Team</span></div>
              </div>
            </div>
          </div>
        </section>

        <section className="section courses-section" id="courses">
          <div className="nova-container">
            <div className="courses-head">
              <div>
                <div className="eyebrow section-kicker">What We Offer</div>
                <h2 className="section-heading">Skills with a<br />clear next step.</h2>
              </div>
              <p className="section-intro">Practical, skill-based courses designed to help you learn, earn, and grow.</p>
            </div>
            <div className="course-grid">
              {courses.map((course, index) => (
                <article className="course-card" key={course.title} data-testid={`card-course-${index + 1}`}>
                  <div className="course-top"><span className="course-number mono">{String(index + 1).padStart(2, '0')} / COURSE</span><span className={`badge ${course.paid ? 'badge-paid' : 'badge-free'}`}>{course.paid ? 'Paid' : 'Free'}</span></div>
                  <h3 className="course-title">{course.title}</h3>
                  <div className="course-meta">
                    <div className="meta-line"><b>Duration</b><span>{course.duration}</span></div>
                    <div className="meta-line"><b>Eligibility</b><span>{course.eligibility}</span></div>
                    <div className="meta-line"><b>{course.delivery === 'Live Classes' ? 'Classes' : 'Lectures'}</b><span>{course.delivery}</span></div>
                  </div>
                  <div className="course-fee"><strong>{course.fee}</strong><span>{course.feeNote}</span></div>
                  <a className="course-action" href={courseWhatsAppLink(course.title)} target="_blank" rel="noopener noreferrer" data-testid={`link-course-register-${index + 1}`}>
                    <MessageCircle size={14} /> Registration / Details <ArrowRight size={13} />
                  </a>
                </article>
              ))}
              <article className="course-card more-card" data-testid="card-more-courses">
                <span className="course-number mono">10 / NEXT</span>
                <h3 className="course-title">More courses coming soon.</h3>
                <p>Many more short courses and workshops are organized and added from time to time.</p>
                <a className="button button-gold" href={WHATSAPP_CHANNEL} target="_blank" rel="noopener noreferrer" data-testid="link-courses-updates">Stay Updated <ArrowRight size={14} /></a>
              </article>
            </div>
          </div>
        </section>

        <section className="section gallery-section" id="gallery">
          <div className="nova-container">
            <SectionHeader eyebrow="Gallery / Flyers" title="A glimpse of the work." description="Course flyers, workshop posters, certificates and academy activity highlights." />
            <div className="gallery-grid">
              {galleryItems.map((item, index) => (
                <article className={`gallery-tile${item.image ? ' has-image' : ''}`} data-testid={`tile-gallery-${index + 1}`} key={item.label}>
                  {item.image && <img className="gallery-image" src={item.image} alt={item.alt} />}
                  <span className="tile-mark">{item.label}</span>
                  <h3 className="tile-title">{item.title}</h3>
                  <p className="tile-subtitle">{item.subtitle}</p>
                  <span className="tile-lines" />
                </article>
              ))}
            </div>
            <p className="gallery-note">To add a poster or certificate, place it in <strong>public/gallery</strong> and set its filename in the gallery list.</p>
          </div>
        </section>

        <section className="section tuition-section" id="tuition">
          <div className="nova-container">
            <SectionHeader eyebrow="Tuition Services" title="Learn with a little more support." description="One-on-one and group tuition for school, college and university students." dark />
            <div className="tuition-grid">
              <article className="tuition-card" data-testid="card-tuition-5-8"><span className="tuition-index">01 / SCHOOL</span><h3 className="tuition-title">Classes<br />5 – 8</h3><strong className="tuition-price">Rs. 1,500</strong><div className="tuition-unit">All Subjects</div></article>
              <article className="tuition-card" data-testid="card-tuition-matric"><span className="tuition-index">02 / COLLEGE</span><h3 className="tuition-title">Matric to<br />Intermediate</h3><strong className="tuition-price">Rs. 1,000</strong><div className="tuition-unit">Per Subject</div></article>
              <article className="tuition-card" data-testid="card-tuition-ads"><span className="tuition-index">03 / UNIVERSITY</span><h3 className="tuition-title">ADS / BS<br />Level</h3><strong className="tuition-price">Rs. 2,000</strong><div className="tuition-unit">Per Subject</div></article>
            </div>
            <p className="tuition-note"><BookOpen size={15} style={{ verticalAlign: 'middle', marginRight: 7 }} /> <strong>Subject notes are available free of cost.</strong></p>
            <div className="tuition-cta"><a className="button button-gold" href={WHATSAPP_MESSAGE} target="_blank" rel="noopener noreferrer" data-testid="link-tuition-whatsapp">Message Us on WhatsApp <Send size={14} /></a></div>
          </div>
        </section>

        <section className="section library-section" id="library">
          <div className="nova-container">
            <div className="library-box" data-testid="card-library">
              <div className="library-icon"><BookOpen size={29} /></div>
              <div className="library-copy"><h2>Reading Books &amp; Library</h2><p>Explore our online collection of reading materials and books.</p></div>
              <a className="button button-primary" href={LIBRARY_LINK} target="_blank" rel="noopener noreferrer" data-testid="link-library-books">Read Books <ChevronRight size={15} /></a>
            </div>
          </div>
        </section>

        <section className="section contact-section" id="contact">
          <div className="nova-container">
            <SectionHeader eyebrow="Get in Touch" title="Let’s start with a question." description="Have a question about a course or tuition? Reach out anytime." />
            <div className="contact-layout">
              <div className="contact-card" data-testid="card-contact-details">
                <div className="contact-item"><span className="contact-icon"><Phone size={17} /></span><div><p className="contact-label">WhatsApp / Call</p><a className="contact-value" href="tel:03086774166" data-testid="link-contact-phone">0308-6774166</a></div></div>
                <div className="contact-item"><span className="contact-icon"><Mail size={17} /></span><div><p className="contact-label">Email</p><a className="contact-value" href="mailto:nova.learn253@gmail.com" data-testid="link-contact-email">nova.learn253@gmail.com</a></div></div>
                <div className="contact-item"><span className="contact-icon"><MessageCircle size={17} /></span><div><p className="contact-label">WhatsApp Channel</p><a className="contact-value" href={WHATSAPP_CHANNEL} target="_blank" rel="noopener noreferrer" data-testid="link-contact-channel">Join Now</a></div></div>
              </div>
              <div className="contact-panel">
                <div className="eyebrow">A human answer awaits</div>
                <h3>Let’s talk about what comes next.</h3>
                <p>Message us on WhatsApp for course details, enrollment, or tuition inquiries. We usually reply within a few hours.</p>
                <div><a className="button button-gold" href={WHATSAPP_MESSAGE} target="_blank" rel="noopener noreferrer" data-testid="link-contact-whatsapp">Message Us on WhatsApp <ArrowRight size={15} /></a></div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer" id="footer">
        <div className="nova-container footer-main">
          <div className="footer-brand">
            <a className="brand" href="#home" onClick={() => navigate('home')} data-testid="link-footer-brand">
              <span className="brand-mark"><img src={novaLogo} alt="Nova Academy logo" /></span>
              <span><h2 className="brand-name">NOVA <span>ACADEMY</span></h2><small className="brand-tagline">Empowering Youth with Skills</small></span>
            </a>
            <p>Practical learning opportunities for students in Pakistan and around the world.</p>
          </div>
          <div>
            <h3 className="footer-heading">Quick Links</h3>
            <ul className="footer-list">{navItems.filter(([id]) => id !== 'gallery').map(([id, label]) => <li key={id}><a className="footer-link" href={`#${id}`} data-testid={`link-footer-${id}`}>{label}</a></li>)}</ul>
          </div>
          <div>
            <h3 className="footer-heading">Contact</h3>
            <ul className="footer-list">
              <li><a className="footer-link" href="tel:03086774166" data-testid="link-footer-phone">0308-6774166</a></li>
              <li><a className="footer-link" href="mailto:nova.learn253@gmail.com" data-testid="link-footer-email">nova.learn253@gmail.com</a></li>
              <li><a className="footer-link" href={WHATSAPP_CHANNEL} target="_blank" rel="noopener noreferrer" data-testid="link-footer-whatsapp">WhatsApp Channel</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">© 2026 Nova Academy. All Rights Reserved.</div>
      </footer>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
